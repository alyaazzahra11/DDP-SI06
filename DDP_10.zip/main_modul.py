import hitung
import bangun_datar
import bangun_ruang

print("----- Hitung -----")

hitung.bagi(40,2)
hitung.kali(7,9)
hitung.kurang(80,19)
hitung.pangkat(6,4)
hitung.tambah(20,58)

print("----- Bagun Datar -----")

bangun_datar.persegi(8)
bangun_datar.persegi_panjang(9,6)
bangun_datar.jajar_genjang(7,5)
bangun_datar.layang_layang(4,6)
bangun_datar.segitiga(4,7)

print("----- Bagun Ruang -----")

bangun_ruang.balok(8,7,6)
bangun_ruang.bola(11)
bangun_ruang.kerucut(8,6)
bangun_ruang.kubus(7)
bangun_ruang.prisma(6,4,3)
bangun_ruang.tabung(8,4)