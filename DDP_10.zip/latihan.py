import hitung
hitung.tambah(5,2)
hitung.kurang(10,3)
hitung.kali(5,6)

import hitung as ht
ht.bagi(20,2)
ht.pangkat(2,3)

from hitung import tambah, kurang
tambah(20,30)
kurang(2,3)

from hitung import *
tambah(20,30)
kurang(2,3)
kali(5,6)
bagi(20,2)
pangkat(2,3)

